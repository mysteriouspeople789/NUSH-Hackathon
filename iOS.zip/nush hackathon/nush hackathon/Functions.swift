//
//  Functions.swift
//  nush hackathon
//
//  Created by Wang Zerui on 22/8/20.
//  Copyright © 2020 Wang Zerui. All rights reserved.
//
// Blank
