//
//  File.swift
//  nush hackathon
//
//  Created by Wang Zerui on 10/8/20.
//  Copyright © 2020 Wang Zerui. All rights reserved.
//

import Foundation

struct ctData: Codable{
    var url: String
    var infected: String
    var dead: String
    var recovered: String
    var name: String
    var data_url: String
}

func save(_ datas: [ctData], key: String) {
    let data = datas.map { try? JSONEncoder().encode($0) }
    UserDefaults.standard.set(data, forKey: key)
}

func load(key: String) -> [ctData] {
    guard let encodedData = UserDefaults.standard.array(forKey: key) as? [Data] else {
        return []
    }

    return encodedData.map { try! JSONDecoder().decode(ctData.self, from: $0) }
}
