//
//  startScreenViewController.swift
//  nush hackathon
//
//  Created by Wang Zerui on 14/8/20.
//  Copyright © 2020 Wang Zerui. All rights reserved.
//

import UIKit
import AVFoundation

class musicUIViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        if lightmd == false{
            overrideUserInterfaceStyle = .dark
        }
        else{
            overrideUserInterfaceStyle = .light
        }
        // Do any additional setup after loading the view.
    }
    

    @IBAction func fadedStart(_ sender: Any) {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.mixWithOthers, .allowAirPlay])
            print("Playback OK")
            try AVAudioSession.sharedInstance().setActive(true)
            print("Session is Active")
        } catch {
            print(error)
        }
        
        if let asset = NSDataAsset(name:"Faded"){
            
            do {
                
                player = try AVAudioPlayer(data:asset.data, fileTypeHint:"mp3")
                player?.play()
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        }
    }
    
    
    
    @IBAction func aloneStart(_ sender: Any) {
        
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.mixWithOthers, .allowAirPlay])
            print("Playback OK")
            try AVAudioSession.sharedInstance().setActive(true)
            print("Session is Active")
        } catch {
            print(error)
        }
        
        if let asset = NSDataAsset(name:"Alone"){
            
            do {
                
                player = try AVAudioPlayer(data:asset.data, fileTypeHint:"mp3")
                player?.play()
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        }
        
    }
    @IBAction func `continue`(_ sender: Any) {
        player?.play()
    }
    @IBAction func pause(_ sender: Any) {
        player?.pause()
    }
    @IBAction func stop(_ sender: Any) {
        player?.stop()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
