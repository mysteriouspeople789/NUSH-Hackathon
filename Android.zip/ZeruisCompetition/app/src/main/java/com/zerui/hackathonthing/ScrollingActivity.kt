package com.zerui.hackathonthing

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Resources
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.MenuItemCompat
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.database.*
import com.squareup.picasso.Callback
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.content_scrolling.*

class ScrollingActivity : AppCompatActivity() {
    private lateinit var database: DatabaseReference
    private lateinit var ref: DatabaseReference
    private lateinit var pref: SharedPreferences
    private lateinit var editor: SharedPreferences.Editor

    private fun updateData() {
        val postListener = object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                // Get Post object and use the values to update the UI
                // var textViewText: String = ""
                val table = findViewById<TableLayout>(R.id.dataTable)
                while (table.childCount > 1) {
                    table.removeView(table.getChildAt(table.childCount - 1))
                }
                val inflater = layoutInflater

                dataSnapshot.children.forEach {
                    var dataList = it.value.toString().drop(1).dropLast(1)
                        .split(", (?=([^\"]*\"[^\"]*\")*[^\"]*$)".toRegex())
                    val row = inflater.inflate(R.layout.one_row, table, false) as TableRow
                    val countryName = it.key

                    // Inflates layout for one row
                    val content = row.findViewById<TextView>(R.id.headerText)
                    if (dataList[0].toString() == "No data") {
                        content.text = "$countryName\nNo Data"
                    }
                    else {
                        content.text = "$countryName\n${dataList[0]} cases"
                    }
                    val imgView = row.findViewById<ImageView>(R.id.countryImg)
                    val highResURL= dataList[3].replace("23px", ((232 *
                            Resources.getSystem().displayMetrics.density).toInt().toString() + "px")).replace("15px", ((232 *
                            Resources.getSystem().displayMetrics.density).toInt().toString() + "px")).replace("20px", ((232 *
                            Resources.getSystem().displayMetrics.density).toInt().toString() + "px")).replace("21px", ((232 *
                            Resources.getSystem().displayMetrics.density).toInt().toString() + "px")).replace("22px", ((232 *
                            Resources.getSystem().displayMetrics.density).toInt().toString() + "px")).replace("14px", ((232 *
                            Resources.getSystem().displayMetrics.density).toInt().toString() + "px")).replace("18px", ((232 *
                            Resources.getSystem().displayMetrics.density).toInt().toString() + "px"))
                    // Wikipedia flags comes with a mess of resolutions

                    Picasso.get().load(dataList[3]) // Thumbnail URL for faster loading
                        .placeholder(R.drawable.ic_round_error)
                        .into(imgView, object : Callback {
                            override fun onSuccess() {
                                Picasso.get()
                                    .load(highResURL) // image url goes here
                                    .placeholder(imgView.drawable)
                                    .into(imgView)
                            }

                            override fun onError(e: Exception?) {
                                // Do nothing here
                            }
                        })
                    // Picasso.get().load(url).placeholder(R.drawable.ic_round_error).into(imgView)
                    row.setOnClickListener {
                        val intent = Intent(this@ScrollingActivity, DetailsView::class.java)
                        intent.putExtra("cases", dataList[0])
                        intent.putExtra("deaths", dataList[1])
                        intent.putExtra("recoveries", dataList[2])
                        intent.putExtra("flagURL", highResURL)
                        //intent.putExtra("flagURL", "https://raw.githubusercontent.com/stevenrskelton/flag-icon/master/png/225/country-4x3/ab.png")
                        intent.putExtra("learnMoreURL", dataList[4])
                        intent.putExtra("country", countryName)
                        intent.putExtra("thumbnailURL", dataList[3])
                        startActivity(intent)
                    }
                    table.addView(row)
                }

                Snackbar.make(
                    findViewById(android.R.id.content),
                    "Updated Data",
                    Snackbar.LENGTH_SHORT // Only show snackbar for short period of time
                ).setAction("Action", null).show()
                indeterminableLoading.visibility = View.GONE
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Getting Post failed, log a message
                Snackbar.make(
                    findViewById<View>(R.id.content),
                    "Could not refresh data",
                    Snackbar.LENGTH_LONG
                ).setAction("Action", null).show()
            }
        }
        indeterminableLoading.visibility = View.VISIBLE
        ref.addValueEventListener(postListener)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!this::database.isInitialized) {
            try {
                // Well Firebase has a bad habit of spitting out errors
                FirebaseDatabase.getInstance().setPersistenceEnabled(true);
            } catch (ex: Exception) {
                // Nothing here!!!
            }
            database = FirebaseDatabase.getInstance().reference
        }
        ref = database.child("nush-hackathon")
        // locations = database.child("locations")
        pref = applicationContext.getSharedPreferences("rickrollPref", Context.MODE_PRIVATE)
        editor = pref.edit()
        setContentView(R.layout.activity_scrolling)
        setSupportActionBar(findViewById(R.id.toolbar))
        findViewById<CollapsingToolbarLayout>(R.id.toolbar_layout).title = title
        findViewById<FloatingActionButton>(R.id.fab).setOnClickListener { view ->
            //Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG).setAction("Action", null).show()
            updateData()
        }
        updateData()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_scrolling, menu)
        val searchView: SearchView =
            MenuItemCompat.getActionView(menu.findItem(R.id.searchBar)) as SearchView
        // searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        // searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.queryHint = "Country"
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextChange(newText: String): Boolean {
                val table = findViewById<TableLayout>(R.id.dataTable)
                var i = table.childCount-1
                var numVisible = 0
                while (i > 0) {
                    var row = table.getChildAt(i)
                    var contentText = row.findViewById<TextView>(R.id.headerText).text
                    if (contentText.contains(newText, ignoreCase = true)) {
                        row.visibility = View.VISIBLE
                        numVisible += 1
                    } else {
                        row.visibility = View.GONE
                    }
                    if (contentText == "No results") {
                        table.removeView(row)
                    }
                    i -= 1
                }
                if (numVisible == 0) {
                    val inflater = layoutInflater
                    val row = inflater.inflate(R.layout.one_row, table, false) as TableRow

                    // Inflates layout for one row
                    val content = row.findViewById<TextView>(R.id.headerText)
                    content.text = "No results"

                    table.addView(row)
                }
                return false
            }

            override fun onQueryTextSubmit(query: String): Boolean {
                return false
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        return when (item.itemId) {
            R.id.action_settings -> {
                return true
            }
            R.id.toMusic -> {
                startActivity(Intent(this@ScrollingActivity, musicPlayer::class.java))
                return true
            }
            R.id.covidLocations -> {
                startActivity(Intent(this@ScrollingActivity, maps::class.java))
                return true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}