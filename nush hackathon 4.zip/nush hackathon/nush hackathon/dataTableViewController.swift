//
//  dataTableViewController.swift
//  nush hackathon
//
//  Created by Wang Zerui on 10/8/20.
//  Copyright © 2020 Wang Zerui. All rights reserved.
//

import UIKit
import FirebaseDatabase
import AVFoundation
import Kingfisher
import CoreLocation
import MapKit

var lightmd = false
var player: AVAudioPlayer?
var pinnedData = load(key: "pinned")
var is_first_load = true
var covid_cooridinate = [String]()
class dataTableViewController: UITableViewController, UISearchBarDelegate, CLLocationManagerDelegate{
    
    var locationManager: CLLocationManager!
    var currentLocation = CLLocation()
    
    let regex = try! NSRegularExpression(pattern: "\\d+px")
    
    var filteredData: [ctData]!
    var test_data = [ctData]()
    var ct_nm = [String]()
    var ref: DatabaseReference?
    @IBOutlet weak var searchBar: UISearchBar!
    
    func convertToDictionary(text: String) -> [String: Any]? {
        if let data = text.data(using: .utf8) {
            do {
                return try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any]
            } catch {
                print(error.localizedDescription)
            }
        }
        return nil
    }
    
    override func viewDidAppear(_ animated: Bool) {
        tableView.reloadData()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager = CLLocationManager()
        locationManager?.delegate = self
        locationManager?.requestAlwaysAuthorization()
        // Do any additional setup after loading the view.
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
        }
        
        alwaysAuthorization()
        if lightmd == false{
            overrideUserInterfaceStyle = .dark
        }
        else{
            overrideUserInterfaceStyle = .light
        }
        searchBar.delegate
         = self
        if is_first_load == true{
            ref = Database.database().reference()
            
            ref!.child("nush-hackathon").observeSingleEvent(of: .value, with: { (snapshot) in
                // Get user value
                let value = snapshot.value as? NSDictionary
                
                for (a, b) in value!{
                    
                    // let pureValue = String(describing: b).replacingOccurrences(of: "\"", with: "", options: .caseInsensitive, range: nil).replacingOccurrences(of: "(", with: "", options: .caseInsensitive, range: nil).replacingOccurrences(of: ")", with: "", options: .caseInsensitive, range: nil).replacingOccurrences(of: "\n", with: "", options: .caseInsensitive, range: nil).replacingOccurrences(of: " ", with: "", options: .caseInsensitive, range: nil)
                    let array = (String(describing: b)).components(separatedBy: ",\n")
                    
                    let url = array[3].trimmingCharacters(in: .whitespacesAndNewlines)
                        .replacingOccurrences(of: ")", with: "", options: .caseInsensitive, range: nil)
                        .replacingOccurrences(of: "\"", with: "", options: .caseInsensitive, range: nil)
                        .replacingOccurrences(of: "\n", with: "", options: .caseInsensitive, range: nil)
                        .replacingOccurrences(of: "[1-9][0-9]px", with: "260px", options: .regularExpression, range: nil)
                    
                    self.ct_nm.append(a as! String)
                    self.test_data.append(ctData(url: url,
                                                 
                                                 infected: array[0].replacingOccurrences(of: "(", with: "", options: .caseInsensitive, range: nil).replacingOccurrences(of: "\n", with: "", options: .caseInsensitive, range: nil).replacingOccurrences(of: " ", with: "", options: .caseInsensitive, range: nil).replacingOccurrences(of: "\"", with: "", options: .caseInsensitive, range: nil),
                                                 
                                                 dead: array[1].replacingOccurrences(of: "(", with: "", options: .caseInsensitive, range: nil).replacingOccurrences(of: "\n", with: "", options: .caseInsensitive, range: nil).replacingOccurrences(of: " ", with: "", options: .caseInsensitive, range: nil).replacingOccurrences(of: "\"", with: "", options: .caseInsensitive, range: nil),
                                                 
                                                 recovered: array[2].replacingOccurrences(of: "(", with: "", options: .caseInsensitive, range: nil).replacingOccurrences(of: "\n", with: "", options: .caseInsensitive, range: nil).replacingOccurrences(of: " ", with: "", options: .caseInsensitive, range: nil).replacingOccurrences(of: "\"", with: "", options: .caseInsensitive, range: nil), name: a as! String,
                                                 
                                                 data_url: array[4].replacingOccurrences(of: ")", with: "", options: .caseInsensitive, range: nil).replacingOccurrences(of: "\n", with: "", options: .caseInsensitive, range: nil).replacingOccurrences(of: " ", with: "", options: .caseInsensitive, range: nil).replacingOccurrences(of: "\"", with: "", options: .caseInsensitive, range: nil)))
                    
                }
                
                self.tableView.reloadData()
                
                // ...
            })
            
            ref!.child("coordinates").observeSingleEvent(of: .value, with: {(snapshot) in
                let value = snapshot.value as! NSArray
                for coordinate in value{
                    covid_cooridinate.append((coordinate as! String).replacingOccurrences(of: ",", with: ""))
                    print(covid_cooridinate)
                }
            })
            
            tableView.dataSource = self
            searchBar.delegate = self
            filteredData = test_data
            
            if test_data.isEmpty == true{
                let defaults = UserDefaults.standard
                self.test_data = defaults.object(forKey: "Offline_data") as? [ctData] ?? [ctData]()
            }
            else{
                let defaults = UserDefaults.standard
                defaults.set(test_data, forKey: "Offline_data")
            }
        }
        else{
            tableView.reloadData()
        }

        
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
        tableView.reloadData()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 2
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        if section == 0{
            return pinnedData.count
        }
        else{
            if is_first_load == false{
                return filteredData.count
            }
            else{
                return test_data.count
            }
        }
        
        
    }
        
    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {

        let sectionName: String
        switch section {
            case 0:
                sectionName = NSLocalizedString("Pinned", comment: "Pinned")
            case 1:
                sectionName = NSLocalizedString("The rest of the world", comment: "The rest of the world")
            default:
                sectionName = ""
        }
        return sectionName
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0{
            let cell = tableView.dequeueReusableCell(withIdentifier: "infoCell", for: indexPath)
            
            // Configure the cell...
            if is_first_load == false{
                let currentData = pinnedData[indexPath.row]
                let url = URL(string: currentData.url)
                // let data = try? Data(contentsOf: url!)
                
                if let cell = cell as? dataTableViewCell{
                    cell.countryName.text = currentData.name
                    cell.infectionNum.text = "Infections: \(currentData.infected)"
                    // cell.picView.image = UIImage(data: data!)
                   cell.picView.kf.setImage(with: url, placeholder: UIImage(named: "unaImg.png"))
                }
                return cell
            }
            else{
                let currentData = pinnedData[indexPath.row]
                let url = URL(string: currentData.url)
                // let data = try? Data(contentsOf: url!)
                if let cell = cell as? dataTableViewCell{
                    cell.countryName.text = currentData.name
                    cell.infectionNum.text = "Infections: \(currentData.infected)"
                    // cell.picView.image = UIImage(data: data!)
                    cell.picView.kf.setImage(with: url, placeholder: UIImage(named: "unaImg.png"))
                }
                return cell
            }
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "infoCell", for: indexPath)
            
            // Configure the cell...
            
            if is_first_load == false{
                let currentData = filteredData[indexPath.row]
                print(currentData)
                let url = URL(string: currentData.url)
                // let data = try? Data(contentsOf: url!)
                if let cell = cell as? dataTableViewCell{
                    cell.countryName.text = currentData.name
                    cell.infectionNum.text = "Infections: \(currentData.infected)"
                    // cell.picView.image = UIImage(data: data!)
                    cell.picView.kf.setImage(with: url, placeholder: UIImage(named: "unaImg.png"))
                }
                return cell
            }
            else{
                let currentData = test_data[indexPath.row]
                print(currentData)
                let url = URL(string: currentData.url)
                // let data = try? Data(contentsOf: url!)
                if let cell = cell as? dataTableViewCell{
                    cell.countryName.text = currentData.name
                    cell.infectionNum.text = "Infections: \(currentData.infected)"
                    // cell.picView.image = UIImage(data: data!)
                    cell.picView.kf.setImage(with: url, placeholder: UIImage(named: "unaImg.png"))
                }
                return cell
            }
        }
        
    }
    
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
     if editingStyle == .delete {
     // Delete the row from the data source
     tableView.deleteRows(at: [indexPath], with: .fade)
     } else if editingStyle == .insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    // MARK: - Buttons
    
    
    
    // MARK: - Navigation
    @IBAction func seeNearbyCases(_ sender: Any) {
        for item in covid_cooridinate{
            let arr = item.split(separator: " ")
            let secondLocation = CLLocation(latitude: NumberFormatter().number(from: String(arr[0]) as String)!.doubleValue
                , longitude: NumberFormatter().number(from: String(arr[1]) as String)!.doubleValue)
            let manager = CLLocationManager()
            guard let locValue: CLLocationCoordinate2D = manager.location?.coordinate else { return }
            currentLocation = CLLocation(latitude: locValue.latitude, longitude: locValue.longitude)
            let distance = currentLocation.distance(from: secondLocation) / 1000
            if (Int(distance) > 1){
                // COVID NEARBY
                performSegue(withIdentifier: "covidNearby", sender: nil)
                return
                
            }
        }
        performSegue(withIdentifier: "noCovidNearby", sender: nil)
    }
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    @IBAction func goToMusicUI(_ sender: Any) {
        performSegue(withIdentifier: "musicUI", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        
        
        if segue.identifier == "showData", let dest = segue.destination as? specificDataViewController, let cSC = tableView.indexPathForSelectedRow{
            if tableView.indexPathForSelectedRow?.section == 0{
                dest.data = pinnedData[tableView.indexPathForSelectedRow!.row]
            }
            else{
                if is_first_load == true{
                    
                    dest.data = test_data[cSC.row]

                }
                else{
                    dest.data = filteredData[cSC.row]

                }
                dest.current_index = tableView.indexPathForSelectedRow!.row
            }

        }
        
    }
    
    // MARK: - Search bar thing
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        is_first_load = false
        // When there is no text, filteredData is the same as the original data
        // When user has entered text into the search box
        // Use the filter method to iterate over all items in the data array
        // For each item, return true if the item should be included and false if the
        // item should NOT be included
        if searchText == "App.Death"{
            test_data.removeAll()
            for nm in ct_nm{
                test_data.append(ctData(url: "https://cdn3.iconfinder.com/data/icons/medicine-stroke/512/skull-512.png", infected: "Death comes for all", dead: "925,663, 262", recovered: "0", name: nm, data_url: "https://www.youtube.com/watch?v=z6AxJYUn2oo"))
            }
            tableView.reloadData()
            lightmd = true
            overrideUserInterfaceStyle = .light
            do {
                try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.mixWithOthers, .allowAirPlay])
                print("Playback OK")
                try AVAudioSession.sharedInstance().setActive(true)
                print("Session is Active")
            } catch {
                print(error)
            }
            if let asset = NSDataAsset(name:"Death"){
                
                do {
                    
                    player = try AVAudioPlayer(data:asset.data, fileTypeHint:"mp3")
                    player?.play()
                    player?.numberOfLoops = -1
                } catch let error as NSError {
                    print(error.localizedDescription)
                }
            }

            
            
        }
        if searchText == "Rick1529"{
            print("RICK ROLL")
            do {
                try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.mixWithOthers, .allowAirPlay])
                print("Playback OK")
                try AVAudioSession.sharedInstance().setActive(true)
                print("Session is Active")
            } catch {
                print(error)
            }
            if let asset = NSDataAsset(name:"Rickroll"){
                
                do {
                    
                    player = try AVAudioPlayer(data:asset.data, fileTypeHint:"mp3")
                    player?.play()
                } catch let error as NSError {
                    print(error.localizedDescription)
                }
            }
            /*
            test_data.removeAll()
            filteredData.removeAll()
            tableView.reloadData()
            */
            
        }
        
        
        
        if searchText == "App.Lm"{
            lightmd = true
            overrideUserInterfaceStyle = .light
            self.navigationController.self?.navigationBar.barTintColor = UIColor(named: "white")
        }
        
        if searchText == "App.Dm"{
            lightmd = false
            overrideUserInterfaceStyle = .dark
            self.navigationController.self?.navigationBar.barTintColor = UIColor(named: "black")
        }
        
        filteredData = searchText.isEmpty ? (test_data ) : (test_data ).filter { (item: ctData) -> Bool in
            // If dataItem matches the searchText, return true to include it
            return item.name.range(of: searchText, options: .caseInsensitive, range: nil, locale: nil) != nil
        }
        
        tableView.reloadData()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func alwaysAuthorization(){
        if CLLocationManager.locationServicesEnabled() && CLLocationManager.authorizationStatus() == .authorizedWhenInUse {
            locationManager.requestAlwaysAuthorization()
        }
    }
    
}
