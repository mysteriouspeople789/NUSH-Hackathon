package com.zerui.hackathonthing

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_music_player.*

class musicPlayer : AppCompatActivity() {
    fun playPause() {
        if (!bgMusicPlayer.isPaused && bgMusicPlayer.isPlaying) {
            val intent = Intent(this@musicPlayer, bgMusicPlayer::class.java)
                .apply {
                    action = "com.zerui.hackathonthing.action.PAUSE"
                }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            }
            pausePlay.setImageDrawable(resources.getDrawable(R.drawable.ic_round_play_arrow_24, applicationContext.theme))
        }
        else {
            val intent = Intent(this@musicPlayer, bgMusicPlayer::class.java)
                .apply {
                    action = "com.zerui.hackathonthing.action.PLAY"
                }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            }
            pausePlay.setImageDrawable(resources.getDrawable(R.drawable.ic_round_pause_24, applicationContext.theme))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_music_player)
        setSupportActionBar(findViewById(R.id.musicToolbar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        if (!bgMusicPlayer.isPaused && bgMusicPlayer.isPlaying) {
            // The music service was playing
            pausePlay.setImageDrawable(resources.getDrawable(R.drawable.ic_round_pause_24, applicationContext.theme))
        }

        playRickroll.setOnClickListener {
            playPause()
        }

        pausePlay.setOnClickListener {
            playPause()
        }
    }
}