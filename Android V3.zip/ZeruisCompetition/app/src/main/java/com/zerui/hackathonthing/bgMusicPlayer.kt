package com.zerui.hackathonthing

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

const val PLAY = "com.zerui.hackathonthing.action.PLAY"
const val PAUSE = "com.zerui.hackathonthing.action.PAUSE"
const val CHANGEMUSIC = "com.zerui.hackathonthing.action.CHANGEMUSIC"

class bgMusicPlayer : Service() {
    lateinit var mediaPlayer: MediaPlayer

    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        val input = intent.getStringExtra("inputExtra")
        createNotificationChannel()
        val notificationIntent = Intent(this, musicPlayer::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0, notificationIntent, 0
        )
        val notification =
            NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("COVID-19 Music Player")
                .setContentText(input)
                .setSmallIcon(R.drawable.ic_launcher_foreground)
                .setContentIntent(pendingIntent)
                .build()
        startForeground(1, notification)

        when (intent?.action) {
            PLAY -> {
                if (isPaused) {
                    mediaPlayer.start()
                    isPaused = false
                }
                else {
                    mediaPlayer = MediaPlayer.create(applicationContext, R.raw.rickroll)
                    mediaPlayer.start()
                    isPlaying = true
                    isPaused = false
                }
            }
            PAUSE -> {
                if (isPlaying && !isPaused) { // Check if the player was actually playing
                    mediaPlayer.pause()
                    isPaused = true
                }
            }
            CHANGEMUSIC -> {

            }
        }

        return START_NOT_STICKY // Don't restart service after being killed for whatever reason
    }

    override fun onBind(intent: Intent): IBinder? {
        return null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "Music Player Notification",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val manager = getSystemService(
                NotificationManager::class.java
            )
            manager.createNotificationChannel(serviceChannel)
        }
    }

    companion object {
        var isPlaying: Boolean = false
        var isPaused: Boolean = false
        const val CHANNEL_ID = "MusicPlayerService"
    }
}