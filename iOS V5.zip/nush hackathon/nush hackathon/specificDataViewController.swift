//
//  specificDataViewController.swift
//  nush hackathon
//
//  Created by Wang Zerui on 10/8/20.
//  Copyright © 2020 Wang Zerui. All rights reserved.
//

import UIKit
import SafariServices

class specificDataViewController: UIViewController, UISearchBarDelegate {
    
    var current_index: Int!
    var data: ctData!
    let ud = UserDefaults.standard
    
    @IBOutlet weak var ctname: UILabel!
    @IBOutlet weak var infecTxt: UILabel!
    @IBOutlet weak var DeadNos: UILabel!
    @IBOutlet weak var recoNos: UILabel!
    @IBOutlet weak var pic: UIImageView!
    @IBOutlet weak var pinButton: UIButton!
    
    var is_pinned = false
    
    override func viewDidLoad() {
        if lightmd == true{
            overrideUserInterfaceStyle = .light
        }
        else{
            overrideUserInterfaceStyle = .dark
        }
        super.viewDidLoad()
        
        for k in pinnedData{
            if k.name == data.name{
                is_pinned = true
                pinButton.setTitle("Unpin it", for: .normal)
            }
        }
            // contains the
        
        let re = data.recovered
        let de = data.dead
        let inf = data.infected
        let ctyname = data.name
        let url = URL(string: data.url)
        do{
            let data = try Data(contentsOf: url!)
            pic.image = UIImage(data: data)
        }
        catch{
            pic.image = UIImage(named: "unaImg.png")
        }
        
        ctname.text = ctyname
        recoNos.text = "Recovered: \(re)"
        DeadNos.text = "Dead: \(de)"
        infecTxt.text = "Infected: \(inf)"
        // Do any additional setup after loading the view.
    }
    
    @IBAction func viewWebPage(_ sender: Any) {
        if let url = URL(string: data.data_url) {
            let config = SFSafariViewController.Configuration()
            config.entersReaderIfAvailable = true

            let vc = SFSafariViewController(url: url, configuration: config)
            present(vc, animated: true)
        }
    }
    
    @IBAction func pinButton(_ sender: Any) {
        if is_pinned == true{
            var index = 0
            for i in pinnedData{
                if i.name == data.name{
                    break
                }
                index += 1
            }
            pinnedData.remove(at: index)
            save(pinnedData, key: "pinned")
            is_pinned = false
            pinButton.setTitle("Pin it", for: .normal)
        }
        else{
            pinnedData.append(data)
            save(pinnedData, key: "pinned")
            is_pinned = true
            pinButton.setTitle("Unpin it", for: .normal)
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
